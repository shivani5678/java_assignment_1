package java_programs;

import java.util.Scanner;

public class GetStudentDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name;
        float marks;
        int roll, math, phy, eng;
         
        Scanner SC = new Scanner(System.in);
         
        System.out.print("Enter Name: ");
        name=SC.nextLine();
        System.out.print("Enter Roll Number: ");
        roll=SC.nextInt();
        System.out.print("Enter marks in Maths, Physics and English: ");
        math=SC.nextInt();
        eng=SC.nextInt();
        phy=SC.nextInt();
         
        marks=math+eng+phy;
        float perc=(float)marks/300*100;
         
        System.out.println("Roll Number:" + roll +"\tName: "+name);
        System.out.println("Marks (Maths, Physics, English): " +math+","+phy+","+eng);
        System.out.println("Marks: "+marks +"\tPercentage: "+perc);
	}

}
